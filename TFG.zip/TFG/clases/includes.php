<?php 
    require_once('clases/categoria.php');
    require_once('clases/producto.php');
    require_once('clases/usuario.php');
    require_once('clases/pedido.php');
    require_once('clases/linea.php');
    require_once('clases/reserva.php');


    $servicio = 2;
    $dbUser = 'ahmed';
    $dbPass = '123456';
    $dbName = 'mosushi';

    $account_sid = 'AC7db1422996d6a07e3728b18af0909cc6';
    $auth_token = '0b7c0d1171e2e8d03a9f7fc4a9519a41';
    $twilio_number = "+13087374265";

    $esendexAccRef = "EX0349427";
    $essendexEmail = "workahmed.m@gmail.com";
    $essendexPass = "145bda674eb4437e8fdb";
?>