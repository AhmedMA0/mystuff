let numPag = 1;
let menuFood = document.getElementById('pagMenu');
let nextButton = document.getElementById('next');
let prevButton = document.getElementById('prev');
let pageDisplay = document.getElementById('pageDisplay');
let header = document.getElementById('header');
let divEncima = document.getElementById('divEncima');
let botonNav = document.getElementById('navB');
