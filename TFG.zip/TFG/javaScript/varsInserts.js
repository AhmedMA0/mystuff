let catButton = document.getElementById('cat');
let prodButton = document.getElementById('prod');
let catForm = document.getElementById('catForm');
let prodForm = document.getElementById('prodForm');
