desplegables =  Array.from(document.getElementsByClassName('lvl1'));
desplegables2 =  Array.from(document.getElementsByClassName('fa-solid'));

desplegandos = Array.from(document.getElementsByClassName('lvl2'));
flechas = Array.from(document.getElementsByClassName('fa-solid'));
botonNav = document.getElementById('navB');
header = document.getElementById('header');
esteNo = document.getElementById('esteNo');
divEncima = document.getElementById('divEncima');