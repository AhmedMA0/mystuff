<?php 
    require_once('clases/categoria.php');
    require_once('clases/producto.php');
?>