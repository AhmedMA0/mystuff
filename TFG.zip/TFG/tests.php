<!DOCTYPE html>
<html>
    <body>
        <?php                
            $a = '324';
            $b = str_replace('P','+',$a);

            echo $b;
        ?>
    </body>
</html>