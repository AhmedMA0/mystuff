let numPag = 1;
let menuFood = document.getElementById('pagMenu');
let nextButton = document.getElementById('next');
let prevButton = document.getElementById('prev');
let pageDisplay = document.getElementById('pageDisplay');