var page = 1;

var paR = document.getElementById('errorR');
var paL = document.getElementById('errorL');
var butR = document.getElementById('botonRegistro');
var reg = document.getElementById('openDR');
var log = document.getElementById('openDL');
var divR = document.getElementById('divReg');
var divL = document.getElementById('divL');
var perfil = document.getElementById("perfil");
var divPerf = document.getElementById("divPerf");
var capaOscura = document.getElementById("relleno");
var html = document.getElementById("html");
var botonPer = document.getElementById("perfil");
var miPerf = document.getElementById('miPerf');
var cerSes = document.getElementById('cerSes');
var h2Perf = document.getElementById('h2Perf');
var imgPerf = document.getElementById('imgPerf');


