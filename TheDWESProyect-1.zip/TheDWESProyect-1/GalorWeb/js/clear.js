function clearImg(){
    document.getElementById('contenedorImagenes').innerHTML = '';
    page = 1;
}