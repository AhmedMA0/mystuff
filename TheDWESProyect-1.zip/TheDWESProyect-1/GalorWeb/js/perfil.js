var botonPer = document.getElementById("perfil");
var capaOscura = document.getElementById("relleno");
var newName = document.getElementById('usuarioIn').value;
var sesionEmail = document.getElementById('hiddenEmail').value;