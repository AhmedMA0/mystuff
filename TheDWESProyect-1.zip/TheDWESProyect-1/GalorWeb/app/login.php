<?php
    require_once('crud.php');

    iniciarSesion($_GET['email'], $_GET['pass']);