<?php
    include_once 'racional.php';

    $rac1 = new Racional('8/5');

    echo $rac1;
?>