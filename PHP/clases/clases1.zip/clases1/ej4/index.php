<?php
    include_once 'racionalCompleto.php';

    $rac1 = new RacionalCompleto(8,12);

    echo $rac1;
?>