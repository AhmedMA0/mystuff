<?php
    define('NOMBRE_SERVIDOR', 'localhost');
    define('NOMBRE_USUARIO', 'ahmed');
    define('PASSWORD', '123456');
    define('NOMBRE_BD', 'crud_empleados');